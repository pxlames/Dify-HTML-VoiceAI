# Dify-HTML-VoiceAI
# 1.update your config
/chat-stt-agent/config
/chat-stt-frontend/static/config/total_config_example.yml

# 2.deploy dify

# 3.start total project